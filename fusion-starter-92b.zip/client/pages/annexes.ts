export const annexes: { title: string; description: string; content: string }[] = [
  {
    title: "Fișa drepturilor copilului",
    description: "Repere pentru discuția despre drepturile și responsabilitățile elevilor.",
    content: `
      <h1>Anexa 1. Fișa drepturilor copilului</h1>
      <p class="meta">Nume și prenume: ______________________________ &nbsp; Clasa: ______ &nbsp; Data: __________</p>
      <p>Fiecare copil are drepturi, indiferent de identitate, origine, limbă, convingeri, capacități sau situație. Respectarea drepturilor înseamnă și respectarea drepturilor celorlalți.</p>
      <table>
        <thead><tr><th>Dreptul meu</th><th>Cum îl respect și pentru ceilalți</th></tr></thead>
        <tbody>
          <tr><td>La demnitate și tratament egal, fără discriminare.</td><td>Accept diferențele și nu jignesc sau exclud.</td></tr>
          <tr><td>La protecție împotriva violenței și umilirii.</td><td>Nu rănesc; cer ajutor unui adult de încredere.</td></tr>
          <tr><td>La educație și la sprijin în învățare.</td><td>Particip și îi încurajez pe ceilalți să învețe.</td></tr>
          <tr><td>Să-mi exprim opinia și să fiu ascultat.</td><td>Ascult și vorbesc fără a-i întrerupe pe ceilalți.</td></tr>
          <tr><td>La viață privată și la respectarea datelor personale.</td><td>Nu divulg informații sau imagini fără acord.</td></tr>
          <tr><td>La odihnă, joacă și participare la viața școlii.</td><td>Îi includ pe ceilalți și respect regulile comune.</td></tr>
        </tbody>
      </table>
      <p>Un drept important pentru mine: __________________________________________________________</p>
      <p>Ce pot face pentru a-l respecta: __________________________________________________________</p>
      <p>Când un drept nu este respectat, pot cere sprijin de la: _______________________________________</p>`,
  },
  {
    title: "Propunerea individuală",
    description: "Fișă pentru contribuția fiecărui elev la pact.",
    content: `
      <h1>Anexa 2. Propunerea individuală</h1>
      <p class="meta">Nume și prenume: ______________________________ &nbsp; Clasa: ______ &nbsp; Data: __________</p>
      <p>Completează o propunere pentru Pactul Respectului și Sprijinului Reciproc. O poți discuta cu reprezentantul clasei.</p>
      <p><strong>Ce situație sau nevoie am observat?</strong></p><div class="writing-space"></div>
      <p><strong>Ce regulă sau acțiune propun?</strong></p><div class="writing-space"></div>
      <p><strong>Cum ne ajută propunerea și pe cine sprijină?</strong></p><div class="writing-space"></div>
      <p><strong>Ce pot face eu pentru aplicarea ei?</strong></p><div class="writing-space"></div>
      <p>Semnătura (opțional): ______________________________</p>`,
  },
  {
    title: "Proces-verbal al ședinței",
    description: "Model cu prezența claselor I–IX, verificarea cvorumului și rezultatul votului.",
    content: `
      <h1>Anexa 3. Proces-verbal al ședinței</h1>
      <p>Data: __________ &nbsp; Ora: __________ &nbsp; Locul: ______________________________</p>
      <p>Scopul ședinței: discutarea și votarea Pactului Respectului și Sprijinului Reciproc.</p>
      <p>Președinte/moderator: __________________________ &nbsp; Secretar: __________________________</p>
      <table class="attendance">
        <thead><tr><th>Clasa</th><th>Reprezentantul</th><th>Prezent</th><th>Absent</th></tr></thead>
        <tbody>
          <tr><td>I</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>II</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>III</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>IV</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>V</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>VI</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>VII</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>VIII</td><td></td><td>☐</td><td>☐</td></tr>
          <tr><td>IX</td><td></td><td>☐</td><td>☐</td></tr>
        </tbody>
      </table>
      <p>Reprezentanți prezenți: _____ din 9. Cvorumul necesar: cel puțin 6 din 9. &nbsp; ☐ Întrunit &nbsp; ☐ Neîntrunit</p>
      <p>Propuneri și modificări discutate: ________________________________________________________</p>
      <p>____________________________________________________________________________________</p>
      <p>Textul supus votului / referința: __________________________________________________________</p>
      <p>Rezultatul votului: PRO _____ &nbsp; CONTRA _____ &nbsp; ABȚINERE _____ &nbsp; Buletine nevalabile _____</p>
      <p>Decizia consemnată, conform regulilor de adoptare aplicabile: __________________________________</p>
      <p>____________________________________________________________________________________</p>
      <p>Semnătura moderatorului: _______________________ &nbsp; Semnătura secretarului: _______________________</p>`,
  },
  {
    title: "Buletin de vot secret",
    description: "Buletin individual pentru votul asupra pactului.",
    content: `
      <h1>Anexa 4. Buletin de vot secret</h1>
      <p>Obiectul votului: adoptarea Pactului Respectului și Sprijinului Reciproc.</p>
      <p>Data: __________ &nbsp; Referința versiunii supuse votului: ______________________________</p>
      <div class="ballot">
        <p><strong>Marchează o singură opțiune:</strong></p>
        <p class="option">☐ &nbsp; PRO</p>
        <p class="option">☐ &nbsp; CONTRA</p>
        <p class="option">☐ &nbsp; ABȚINERE</p>
      </div>
      <p>Votul este secret. Nu scrie numele și nu semna buletinul.</p>`,
  },
  {
    title: "Model orientativ de pact",
    description: "Trei articole propuse pentru diversitate, sprijin și dialog; textul nu este adoptat automat.",
    content: `
      <h1>Anexa 5. Model orientativ de pact</h1>
      <p><strong>Propunere pentru discuție, nu text adoptat.</strong> Articolele pot fi modificate înainte de vot.</p>
      <h2>Articolul 1. Respectarea diversității</h2>
      <p>Ne respectăm reciproc, indiferent de identitate, origine, limbă, convingeri, capacități sau alte diferențe. Nu acceptăm jignirea, discriminarea ori excluderea.</p>
      <h2>Articolul 2. Sprijin reciproc</h2>
      <p>Ne ajutăm la învățare și în viața școlii, fără a umili sau a lăsa pe cineva deoparte. Când o situație ne depășește, cerem ajutorul unui adult de încredere.</p>
      <h2>Articolul 3. Dialog și soluționarea neînțelegerilor</h2>
      <p>Ne exprimăm opiniile cu respect, ascultăm puncte de vedere diferite și căutăm soluții pașnice. Dacă este nevoie, apelăm la sprijinul unui cadru didactic.</p>
      <p>Propuneri de modificare: ________________________________________________________________</p>
      <div class="writing-space"></div>`,
  },
  {
    title: "Act de promulgare",
    description: "Model de promulgare, care se completează numai după adoptarea pactului.",
    content: `
      <h1>Anexa 6. Act de promulgare</h1>
      <p><strong>Se completează și se semnează numai dacă pactul a fost adoptat.</strong> Dacă nu a fost adoptat, nu se promulgă.</p>
      <p>În temeiul procesului-verbal din data de __________, în care se consemnează întrunirea cvorumului și adoptarea pactului conform regulilor aplicabile, se promulgă <strong>Pactul Respectului și Sprijinului Reciproc</strong> al IPG „Anatolie Sîrghi”, Talmaza.</p>
      <p>Data ședinței de adoptare: __________ &nbsp; Numărul / referința procesului-verbal: __________________</p>
      <p>Rezultatul votului consemnat: PRO _____ &nbsp; CONTRA _____ &nbsp; ABȚINERE _____</p>
      <p>Data promulgării: __________ &nbsp; Data aplicării: __________</p>
      <p>Textul promulgat este cel consemnat în foaia pentru textul final adoptat.</p>
      <p>Numele și funcția persoanei care promulgă: _________________________________________________</p>
      <p>Semnătura: ______________________________</p>`,
  },
  {
    title: "Textul final adoptat și semnături",
    description: "Foaie pentru consemnarea textului adoptat și a semnăturilor.",
    content: `
      <h1>Anexa 7. Textul final adoptat și semnături</h1>
      <p>Data adoptării: __________ &nbsp; Referința procesului-verbal: ______________________________</p>
      <p>Se transcrie textul exact adoptat. Dacă este nevoie, se anexează pagini suplimentare numerotate.</p>
      <h2>Pactul Respectului și Sprijinului Reciproc</h2>
      <div class="final-text"></div>
      <p>Număr total de pagini ale textului, inclusiv anexe: _____</p>
      <table>
        <thead><tr><th>Nume și prenume</th><th>Calitatea / clasa</th><th>Semnătura</th></tr></thead>
        <tbody>
          <tr><td>&nbsp;</td><td></td><td></td></tr><tr><td>&nbsp;</td><td></td><td></td></tr>
          <tr><td>&nbsp;</td><td></td><td></td></tr><tr><td>&nbsp;</td><td></td><td></td></tr>
          <tr><td>&nbsp;</td><td></td><td></td></tr><tr><td>&nbsp;</td><td></td><td></td></tr>
        </tbody>
      </table>`,
  },
  {
    title: "Fișă de autoevaluare",
    description: "Reflecție individuală asupra respectului, sprijinului și dialogului.",
    content: `
      <h1>Anexa 8. Fișă de autoevaluare</h1>
      <p class="meta">Nume (opțional): __________________________ &nbsp; Clasa: ______ &nbsp; Data: __________</p>
      <p>Gândește-te la ultima perioadă și marchează câte o opțiune pentru fiecare afirmație.</p>
      <table>
        <thead><tr><th>Afirmație</th><th>Deseori</th><th>Uneori</th><th>Încă exersez</th></tr></thead>
        <tbody>
          <tr><td>Îi respect pe ceilalți și diferențele dintre noi.</td><td>☐</td><td>☐</td><td>☐</td></tr>
          <tr><td>Ascult fără să întrerup sau să jignesc.</td><td>☐</td><td>☐</td><td>☐</td></tr>
          <tr><td>Ofer sprijin și îi includ pe ceilalți.</td><td>☐</td><td>☐</td><td>☐</td></tr>
          <tr><td>Îmi exprim neînțelegerile prin dialog.</td><td>☐</td><td>☐</td><td>☐</td></tr>
          <tr><td>Cer ajutor când nu pot rezolva o situație.</td><td>☐</td><td>☐</td><td>☐</td></tr>
        </tbody>
      </table>
      <p><strong>Ce am făcut bine?</strong></p><div class="writing-space"></div>
      <p><strong>Ce vreau să îmbunătățesc și cum?</strong></p><div class="writing-space"></div>`,
  },
  {
    title: "Certificat de participare",
    description: "Model de certificat pentru participarea la activitățile dedicate pactului.",
    content: `
      <div class="certificate">
        <p>Anexa 9</p>
        <h1>Certificat de participare</h1>
        <p>Se acordă elevei / elevului</p>
        <p class="certificate-name">________________________________________________</p>
        <p>din clasa __________, pentru participarea la activitățile dedicate<br><strong>Pactului Respectului și Sprijinului Reciproc</strong>.</p>
        <p>Prin implicare, contribuie la o comunitate școlară bazată pe respect, sprijin și dialog.</p>
        <p>Data: __________________ &nbsp;&nbsp;&nbsp; Locul: Talmaza</p>
        <p>Reprezentantul instituției: ______________________________</p>
        <p>Semnătura: ______________________________</p>
      </div>`,
  },
];

/** Descarcă anexa indicată prin indexul său (începând de la zero). */
export function downloadAnnex(index: number): void {
  if (!Number.isInteger(index) || index < 0 || index >= annexes.length) {
    throw new RangeError("Index de anexă invalid.");
  }

  const annex = annexes[index];
  const html = `<!doctype html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Anexa ${index + 1} - Pactul Respectului și Sprijinului Reciproc</title>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; background: #fff; color: #000; font: 12pt/1.35 Arial, sans-serif; }
    main { max-width: 210mm; margin: 0 auto; padding: 12mm; }
    .toolbar { max-width: 210mm; margin: 12px auto 0; padding: 0 12mm; }
    button { border: 1px solid #000; background: #fff; color: #000; padding: 8px 12px; font: inherit; cursor: pointer; }
    header { border-bottom: 1px solid #000; margin-bottom: 10px; padding-bottom: 6px; text-align: center; font-size: 10pt; }
    h1 { font-size: 16pt; line-height: 1.2; margin: 10px 0; }
    h2 { font-size: 12pt; margin: 10px 0 4px; }
    p { margin: 7px 0; }
    table { border-collapse: collapse; width: 100%; margin: 8px 0; font-size: 10pt; }
    th, td { border: 1px solid #000; padding: 4px 6px; text-align: left; vertical-align: top; }
    th { font-weight: bold; }
    .attendance th:nth-child(n+3), .attendance td:nth-child(n+3) { text-align: center; width: 14%; }
    .writing-space { height: 46px; background: repeating-linear-gradient(to bottom, transparent 0, transparent 21px, #000 22px, transparent 23px); }
    .final-text { height: 220px; background: repeating-linear-gradient(to bottom, transparent 0, transparent 21px, #000 22px, transparent 23px); }
    .ballot { border: 1px solid #000; padding: 10px 18px; margin: 16px 0; }
    .option { font-size: 14pt; margin: 14px 0; }
    .certificate { border: 2px solid #000; padding: 20mm 10mm; text-align: center; }
    .certificate-name { font-size: 15pt; margin: 22px 0; }
    @page { size: A4; margin: 12mm; }
    @media print {
      .toolbar { display: none; }
      main { max-width: none; margin: 0; padding: 0; }
      body { font-size: 11pt; }
      tr, .ballot, .certificate { break-inside: avoid; }
    }
  </style>
</head>
<body>
  <div class="toolbar"><button type="button" onclick="window.print()">Tipărește / Salvează ca PDF</button></div>
  <main>
    <header>IPG „Anatolie Sîrghi”, Talmaza<br>Pactul Respectului și Sprijinului Reciproc · Clasele I–IX</header>
    ${annex.content}
  </main>
</body>
</html>`;

  const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = `anexa-${index + 1}.html`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
